

import swiftbot.*;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import javax.imageio.ImageIO;
import java.time.format.DateTimeFormatter;


public class Swiftbotuserinput {
    //initialise all the variables
	static SwiftBotAPI swiftBot; 
    static Scanner scanner;
    static String userinput= "";    
    static String strdecimal;
    static String lettercolour;
    static int decimal;
    static int convoctal;
    static int[] colour;
    static String convertedhex = "";
    static String convbin = "";
    static String valuebinary = "";
	static int duration;

	static String[] starttime;
	static String[] endtime;
	static double starthour;
	static double startminute;
	static double startseconds;
	static double endhour;
	static double endminute;
	static double endseconds;
	private static long StartTime = 0;
	private static double Time = 0;	
	static String[] lcolour;
	static int speed = 0;


	
public static void main(String[] args) throws IOException {
		
		// welcome user interface
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Welcome to ");
		System.out.println(" ");
		System.out.println("\r\n"
				+ "   _____         _  __ _   _           _                   _ _   \r\n"
				+ "  / ____|       (_)/ _| | | |         | |                 (_) |  \r\n"
				+ " | (_____      ___| |_| |_| |__   ___ | |_   _ __ ___  ___ _| |_ \r\n"
				+ "  \\___ \\ \\ /\\ / / |  _| __| '_ \\ / _ \\| __| | '__/ _ \\/ __| | __|\r\n"
				+ "  ____) \\ V  V /| | | | |_| |_) | (_) | |_  | | |  __/\\__ \\ | |_ \r\n"
				+ " |_____/ \\_/\\_/ |_|_|  \\__|_.__/ \\___/ \\__| |_|  \\___||___/_|\\__|\r\n"
				+ "                                                                 \r\n"
				+ "                                                                 \r\n"
				+ "");
		System.out.println(" ");
		System.out.println(" By Kishan poonyth (2272384)");
		System.out.println(" ");
		System.out.println("-----------------------------------------------------------------");
		System.out.println(" ");
		
		System.out.println("Press Button A to start or press button X to End");
		
		swiftBot = new SwiftBotAPI();
		swiftBot.enableButton(Button.A, () -> {
			
			swiftBot.disableButton(Button.A);
				playgame();//runs the method that will allow the user to play the game 
				
				
			
		});
		
		swiftBot.enableButton(Button.X, () -> {
			
			//exit program
				System.out.println("Terminating program");
				System.out.println("\r\n"
						+ " .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.  .----------------.   .----------------.  .----------------.  .----------------.  .----------------.   .----------------.  .----------------.  .----------------.  .----------------.  .-----------------.\r\n"
						+ "| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. || .--------------. | | .--------------. || .--------------. || .--------------. || .--------------. | | .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |\r\n"
						+ "| |   ______     | || |  ____  ____  | || |  _________   | || |              | || |              | || |              | || |              | | | |     ______   | || |     ____     | || | ____    ____ | || |  _________   | | | |      __      | || |    ______    | || |      __      | || |     _____    | || | ____  _____  | |\r\n"
						+ "| |  |_   _ \\    | || | |_  _||_  _| | || | |_   ___  |  | || |      _       | || |      _       | || |      _       | || |      _       | | | |   .' ___  |  | || |   .'    `.   | || ||_   \\  /   _|| || | |_   ___  |  | | | |     /  \\     | || |  .' ___  |   | || |     /  \\     | || |    |_   _|   | || ||_   \\|_   _| | |\r\n"
						+ "| |    | |_) |   | || |   \\ \\  / /   | || |   | |_  \\_|  | || |     | |      | || |     | |      | || |     | |      | || |     | |      | | | |  / .'   \\_|  | || |  /  .--.  \\  | || |  |   \\/   |  | || |   | |_  \\_|  | | | |    / /\\ \\    | || | / .'   \\_|   | || |    / /\\ \\    | || |      | |     | || |  |   \\ | |   | |\r\n"
						+ "| |    |  __'.   | || |    \\ \\/ /    | || |   |  _|  _   | || |     | |      | || |     | |      | || |     | |      | || |     | |      | | | |  | |         | || |  | |    | |  | || |  | |\\  /| |  | || |   |  _|  _   | | | |   / ____ \\   | || | | |    ____  | || |   / ____ \\   | || |      | |     | || |  | |\\ \\| |   | |\r\n"
						+ "| |   _| |__) |  | || |    _|  |_    | || |  _| |___/ |  | || |     | |      | || |     | |      | || |     | |      | || |     | |      | | | |  \\ `.___.'\\  | || |  \\  `--'  /  | || | _| |_\\/_| |_ | || |  _| |___/ |  | | | | _/ /    \\ \\_ | || | \\ `.___]  _| | || | _/ /    \\ \\_ | || |     _| |_    | || | _| |_\\   |_  | |\r\n"
						+ "| |  |_______/   | || |   |______|   | || | |_________|  | || |     |_|      | || |     |_|      | || |     |_|      | || |     |_|      | | | |   `._____.'  | || |   `.____.'   | || ||_____||_____|| || | |_________|  | | | ||____|  |____|| || |  `._____.'   | || ||____|  |____|| || |    |_____|   | || ||_____|\\____| | |\r\n"
						+ "| |              | || |              | || |              | || |     (_)      | || |     (_)      | || |     (_)      | || |     (_)      | | | |              | || |              | || |              | || |              | | | |              | || |              | || |              | || |              | || |              | |\r\n"
						+ "| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' || '--------------' | | '--------------' || '--------------' || '--------------' || '--------------' | | '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |\r\n"
						+ " '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'  '----------------'   '----------------'  '----------------'  '----------------'  '----------------'   '----------------'  '----------------'  '----------------'  '----------------'  '----------------' \r\n"
						+ "");
				
				System.exit(0);
				
				
			

			
			swiftBot.disableButton(Button.X);

		});
		
	}

	public  static void playgame() {
		// initialises variables and runs each required method in order. 
		String qrcoderesult = ScanQRcode();
		
		int tempdecimal = stringtoint(qrcoderesult);
		
		String[] letcolour = getletters(qrcoderesult);
		lcolour = letcolour;
		int octspeed = decimaltooctal(tempdecimal);
		
		String hextime = dectohex(tempdecimal);
		decimal = tempdecimal;
		
		String binarymove = decimaltobinary(tempdecimal);
		
		int Speed = botspeed(octspeed);
		currentstarttime();//display current time
	
		swiftbotlightcolour(lcolour);
		swiftBot.disableUnderlights();
		
		long STARTTIME = System.currentTimeMillis();//starts a timer
		movementseq(octspeed, binarymove);
		long ENDTIME = System.currentTimeMillis();//ends timers
		swiftbotlightcolour(lcolour);
		swiftBot.disableUnderlights();
		
		
		currentendtime();//display current time 
		
		//calculates duration of movement based on timer
		Time = ((ENDTIME-STARTTIME)/1000);
		System.out.println("The total duration of the journey was : " + Time + " seconds. " );
		 
		
		//file handling
		try {
            File file = new File("/home/pi/Documents/scannedmovement.txt");
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        try (FileWriter file = new FileWriter("/home/pi/Documents/scannedmovement.txt")) {
            // put variables in file
        	file.write("The scanned qr code gave : " + qrcoderesult);
        	file.write("");
        	file.write("The octal number of the decimal input is : " + octspeed);
        	file.write("");
        	file.write("The hexadecimal number of the decimal input is : " + hextime);
        	file.write("");
        	file.write("The binary value of the decimal input is : " + binarymove);
        	file.write("");
        	file.write("The total duration of the journey was : " + Time + " seconds. " );

            // inform player where file is stored
            System.out.println("File created successfully!");
            System.out.println("File location: " + System.getProperty("user.dir") + "/user_data.txt");
        } catch (IOException e) {
            System.err.println("Error creating file: " + e.getMessage());
        }
    
       //checks if user wants to play again
    	System.out.println("Would you like to play again? Press Y to continue");
    	 
        swiftBot.enableButton(Button.Y, () -> {
        	
        	playgame();
        	 
        	 
        	swiftBot.disableButton(Button.Y);
        	
	
        });
	}

	public static String ScanQRcode() {

    	
    	//scanning qrcode
    	
	
    		System.out.println("Capurting image...");
    		

    		
    		
    			BufferedImage img = swiftBot.getQRImage();
    			try {
    				userinput = swiftBot.decodeQRImage(img);
    			if(!userinput.isEmpty()){
   	    	     System.out.println("Scan Successful......processing " 
    			+ userinput);
   	    	     
   	    	  }
   	    	  
  	        }catch (IllegalArgumentException  e) {
  	            e.printStackTrace();//outputs error message if there is no qrcode scanned or the qrcode scanned is invalid
  	            System.out.println("This is the error " + e.getMessage());
    				
    			}
    			
    		
    		
    		return userinput;

    }
    
    public static int stringtoint(String args) {
        //separating the decimal value from the qrcode scanned
    	String temp = userinput;
        String[] parts = temp.split(":");
        //checks if the decimal scanned is empty
        strdecimal = parts[0];
        if (!strdecimal.isEmpty()) {
            decimal = Integer.parseInt(strdecimal);
        } else {
            System.out.println("Error: strdecimal is empty");
        }
        
        return decimal;
        
        
    }
    public static String[] getletters(String userinput) {
    	//separating the colour from the qrcode scanned
    	String temp = userinput;
       String[] parts = temp.split(":");
    	
    	lettercolour = parts[1];
    	String converter = lettercolour;
    	String[] lcolour = converter.split("");
    	
    	return lcolour;
    	    	
    	
    }
      
    public static int decimaltooctal(int args) {
    	//checks if decimal value is 0
    	if (decimal == 0) {
    		return 0;
    	}
    	
    	String Valueoctal = "";
    	String convertedoctalstring = "";
    	while (decimal > 0) {
    		int remainderoct = decimal % 8;
    		Valueoctal += Integer.toString(remainderoct);
    		decimal /= 8;
    	}
    	//reversing octal array
    	for (int i = 0; i < Valueoctal.length(); i++) {
    		convertedoctalstring = Valueoctal.charAt(i) + convertedoctalstring;
    	}
    	int convoctal = Integer.parseInt(convertedoctalstring);
    	return convoctal;
    }
    
    
    public static String dectohex(int args) {
    	//converting decimal to hexadecimal
    	int remainderhex;
    	  // creating char array for all the possible characters in a hexadecimal value 	
    	char hexa[] = {'1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
    	
    	while (decimal > 0 )
    	{
    		remainderhex = decimal %16;
    		//to reverse hex array
    		convertedhex= hexa[remainderhex]+convertedhex;
    		decimal = decimal%16;
    	}
    	return convertedhex;
    }
    
    public static String decimaltobinary(int args) {
    	//converts decimal into binary
    	if (decimal == 0) {
    		return "0";
    	}
    	
    	

    	while (decimal > 0 ) {
    		int  reminderbin = decimal % 2;
    		valuebinary += Integer.toString(reminderbin);
    		decimal /= 2;
    	}
    	//reversing binary array
    	for (int i = 0; i < valuebinary.length(); i++) {
    		convbin = valuebinary.charAt(i) + convbin;
    	}
    	return convbin;
    	
    }
    

public static void swiftbotlightcolour(String[] lcolour) {
    	//creates varaibles for |the value of Red, green, blue
    	int r = 100, g = 0, b = 0;  
        
        //
        for (String incolour : lcolour) {
            switch (incolour.toLowerCase()) {
                case "red":
                    r = 255;
                    break;
                case "blue":
                    b = 255;
                    break;
                case "green":
                    g = 128;
                    break;
                case "white":
                    r = 255;
                    g = 255;
                    b = 255;
                    break;
            }
        }
        
        int[] colours = {r, g, b};
        // turns the swift bots lights on
        swiftBot.fillUnderlights(colours);
        

        
    }
       
            
            
    public static int botspeed(int args) {
    	int maximumSpeed = 100;
		int speed = 0;
		//will determine the speed of the swiftbot forward movement based on the octal value being higher or lower than 50
    	if (convoctal > 50) {
    		if (convoctal > maximumSpeed) {
    			speed = maximumSpeed;
    		}
    		else {
    			return speed = convoctal - 50;
    		}
    	}
    	else {
    		return speed = convoctal + 50;
    	}
    	
		return speed;	
	}
    public static void movementseq(int octspeed, String binarymove) {

    
    	int Speeds = botspeed(speed);
    	int duration = 1000;
    	if (convertedhex.length() == 1) { // assigning the duration of forward movement
    									//of the swiftbot depending on the length of the hexadecimal
    		duration = 1000;
    		
    		
    	} else if (convertedhex.length() == 2) {
    		duration = 2000;
    		
    		
    	}
    	
    	char[] movement = binarymove.toCharArray();
    	for (char direction : movement) { //read the array until the last value
    		//determines whether it is a 1 or 0
    		if (direction == '1') {
    			
    			 System.out.println("Moving forward");
    				swiftBot.move(octspeed, octspeed, duration);
    				swiftBot.stopMove();
    				 System.out.println("Moving to the right");
    				swiftBot.move(100, 0, 1000);
    				swiftBot.stopMove();


								
    		}else if (direction == '0') {
    			   			
    			 System.out.println("Moving forward");
    				swiftBot.move( octspeed , octspeed, duration );
    				swiftBot.stopMove();
    				System.out.println("Moving to the left");
    				swiftBot.move( 0 , 100, 1000 );
    				swiftBot.stopMove();

    			
    			}
    		}
    	
    	}


	public static String currentstarttime() {
		//shows the time at the start of the program in HH:MM:SS
		LocalTime Currentstarttime = LocalTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // formatting to HH:MM:SS
	    String formattedTime = Currentstarttime.format(formatter);
	    System.out.println("The Current Start time is --> " + formattedTime);
	    return formattedTime;
	}
	
	
	public static String currentendtime() {
		//shows the time at the end of the program in HH:MM:SS
	    LocalTime Currentendtime = LocalTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // formatting to HH:MM:SS
	    String formattedTime = Currentendtime.format(formatter);
	    System.out.println("The Current End time is --> " + formattedTime);
	    return formattedTime;
	}
	

	


}
